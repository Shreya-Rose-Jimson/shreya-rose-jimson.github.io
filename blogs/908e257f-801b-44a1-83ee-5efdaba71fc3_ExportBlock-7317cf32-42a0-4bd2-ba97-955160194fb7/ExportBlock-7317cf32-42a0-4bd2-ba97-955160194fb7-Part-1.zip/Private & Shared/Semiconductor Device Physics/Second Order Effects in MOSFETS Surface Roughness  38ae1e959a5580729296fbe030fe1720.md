# Second Order Effects in MOSFETS: Surface Roughness Scattering

Imagine a river flowing calmly down a smooth, wide, concrete aqueduct. The water moves swiftly with almost zero resistance. But now, imagine a fierce crosswind suddenly blows across the water, violently pushing the entire river hard against one of the banks. If that bank is made of jagged, sharp, protruding rocks, the water will churn, crash, and slow down massively as it scrapes against the rough edge.

In a MOSFET, our electrons are the water, the gate's vertical electric field is the crosswind, and the Si-SiO2 interface is the jagged rock wall. This beautiful, yet destructive phenomenon is known as **Surface Roughness Scattering**.

Let us break down the physical reality and the mathematical elegance of this nanoscale chaos in bite-sized pieces!

**1. The Nanoscale Reality**

When we fabricate a MOSFET, the transition between the crystalline silicon substrate and the amorphous silicon dioxide (SiO2) is incredibly sharp, but it is not perfectly flat. Even with state-of-the-art manufacturing, there are atomic-level fluctuations—random "steps" or "islands" that are about one to two monolayers high (roughly 0.2 to 0.5 nm).

When you apply a positive gate voltage to turn an NMOS transistor on, it creates a massive vertical electric field. This field confines our electrons into a very narrow 2D quantum well directly against this imperfect Si-SiO2 boundary. Because the electrons are pressed so tightly against this boundary, they collide constantly with these microscopic bumps, which brutally degrades their mobility. This is exactly why the typical electron mobility in a silicon MOSFET channel is only about 600 cm2/(V⋅s), compared to a glorious 1300 cm2/(V⋅s) in pure bulk silicon!

**2. The Mathematical Perturbation**

Now, let us put our mathematical hats on. How do we model a random, jagged wall? We treat the roughness as a two-dimensional, position-dependent fluctuation function, Δ(**r**), where **r** is the vector in the plane of the interface.

The potential energy seen by the electron is altered by this boundary perturbation. We can write the surface roughness potential *Vsr* using a Taylor series expansion of the effective 1D vertical confining potential, *Veff*(*z*): 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image.png)

Look at how profound this is! It tells us that the scattering potential is directly proportional to how "bumpy" the surface is (Δ(**r**)) multiplied by the steepness of the confining potential (the vertical electric field).

**3. The Matrix Element**

To find out how often an electron scatters from an initial momentum state **k** to a final state **k**′, we must find the quantum mechanical scattering matrix element. By integrating our potential over the *z*-direction, the derivative of the potential elegantly yields the average effective electric field at the surface, *Favg*.

The matrix element becomes: 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image%201.png)

where **q**=**k**−**k**′ is the change in momentum, and Δ(**q**) is the 2D Fourier transform of our roughness function.

**4. The Power Spectrum (Statistics of Chaos)**

Because the atomic bumps are entirely random, we cannot know Δ(**q**) exactly. Instead, we must use statistics! We define an autocovariance function to describe the average height and lateral spread of the bumps. Historically, physicists modeled this with a Gaussian distribution: 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image%202.png)

Here, Δ is the root-mean-square (rms) height of the bumps, and *L* is the autocovariance length (how wide the bumps are on average). By taking the Fourier transform of this autocovariance function, we obtain the power spectrum *S*(**q**) of the roughness: 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image%203.png)

*(Note: Modern High-Resolution Transmission Electron Microscopy (HRTEM) measurements reveal that an exponential function actually fits the physical reality of the Si-SiO*2 *interface slightly better than a Gaussian, but the statistical mechanics remain exactly the same!)*.

**5. The Macroscopic Circuit Impact**

When we plug this power spectrum into Fermi's Golden Rule to calculate the total scattering rate, we find that the rate is incredibly sensitive to the vertical field. As you increase the gate-source voltage (*VGS*), *Favg* increases, and the electrons are crushed harder against the surface bumps.

In macroscopic device modeling, this intense scattering reduces the effective mobility *μeff*. We commonly approximate this degradation algebraically as: 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image%204.png)

where *μ*0 is the low-field mobility and *θ* is a fitting parameter (roughly 10−7/*tox*) that depends heavily on the oxide thickness.

As we push into the regime of ultra-small nanoscale devices (like nanowires or ultra-thin-body FETs), an enormous fraction of the carriers are forced to interact with the surfaces and interfaces. For these modern devices, surface roughness scattering becomes one of the absolute primary limits on device mobility and performance.

How do surface roughness and mobility affect switching speed?

**1. The Root Cause: Surface Roughness Scatters the Carriers**

As we established, the transition between the crystalline silicon and the amorphous silicon dioxide (*SiO*2) is not perfectly flat; it contains microscopic islands of roughness on the order of 5 A˚ in height. When we apply a strong vertical gate voltage to turn the transistor on, the electrons are pulled tightly against this jagged interface.

Because the electrons are scraping against this atomic roughness, they scatter frequently, which drastically reduces their mobility (*μ*). We mathematically model this degraded effective mobility as:

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image%205.png)

 where *μ*0 is the low-field mobility and *θ* is an empirical fitting parameter. The harder we drive the gate voltage (*VGS*), the more the mobility degrades.

**2. The Digital Consequence: Increased RC Delay**

To understand switching speed in digital circuits, we must view the MOSFET as a switch that charges and discharges a load capacitor (*CH*). The speed of this transition is governed by the *RC* time constant, 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image%206.png)

When the transistor is turned firmly "on" in the deep triode region, it behaves as a linear resistor whose value is defined as: 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image%207.png)

where *Cox* is the oxide capacitance and *W*/*L* is the aspect ratio.

Look at where the mobility *μn* sits in this elegant equation—exactly in the denominator. Because surface roughness severely degrades *μn*, the on-resistance *Ron* physically increases. When *Ron* goes up, the *RC* charging time constant (*τ*) becomes longer, meaning it takes significantly more time for the output voltage to settle to its final logic state. The rougher the surface, the slower the switch!

**3. The Analog Consequence: Choking the Transconductance**

In analog and high-frequency RF design, we evaluate speed by looking at the transconductance (*gm*), which measures how effectively a change in the gate voltage modulates the drain current. For a device operating in saturation without severe velocity saturation, the transconductance is given by:

 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20/image%208.png)

 which shows a direct, linear proportionality to mobility.

Because surface roughness scattering suppresses *μn*, it directly crushes the transconductance. The transistor effectively loses its "sensitivity" and cannot pump as much current into the load for a given input signal.

**4. The Ultimate Speed Limit: Degrading the Cutoff Frequency (*f_T*)**

To find the absolute maximum switching speed of a transistor, we calculate its cutoff frequency (*fT*). This is the spectacular frequency at which the small-signal current gain of the device drops exactly to unity.

Fundamentally, *fT* is limited by the intrinsic transit time (*t_tr*) that it takes for a carrier to travel from the source to the drain. Because carrier velocity is *v*=*μE* (at low fields), a lower mobility means the electron travels slower, increasing the transit time.

Mathematically, the cutoff frequency is defined by the ratio of the transconductance to the total gate capacitance (*CG*): *fT*=2*πCGgm* By substituting our equation for *gm* and setting *CG*≈*WLCox*, we can rewrite the cutoff frequency as: *fT*=2*πL*2*μn*(*VGS*−*VTH*) This is the grand finale of our chain reaction. Because the cutoff frequency is directly proportional to the carrier mobility, the interface roughness physically lowers the maximum operating frequency of the entire device.

**Surface roughness** creates microscopic scattering → which drops the **carrier mobility** → which increases the **on-resistance** and lowers the **transconductance** → which fundamentally increases the **transit time** and limits the ultimate **switching speed (***fT***)**.