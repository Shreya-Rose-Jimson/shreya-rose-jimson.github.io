# Second Order Effects in MOSFETS: Gate-Induced Drain Leakage (GIDL)

### 

![](https://cdn-images-1.medium.com/max/1200/1*bkVkzCGLQAzu8LErxHMw9Q.png)

EEC 216 Lecture #9: Leakage Rajeevan Amirtharajah University of California, Davis

**Gate-Induced Drain Leakage (GIDL)** is a leakage current that occurs in a MOSFET when there is a **strong electric field between the gate and drain**, typically when:

- The **gate voltage is low** (or negative for an NMOS),
- The **drain voltage is high**,
- The transistor is supposed to be **OFF**.

### Physical Mechanism

Under these bias conditions, the large electric field near the gate-drain overlap region bends the semiconductor energy bands significantly. This can cause **band-to-band tunneling (BTBT)**, where electrons tunnel directly from the valence band to the conduction band.

For an **NMOS**:

1. A high drain voltage and low gate voltage create a strong field near the drain edge.
2. Electrons tunnel from the silicon valence band into the conduction band.
3. Electron-hole pairs are generated.
4. The electrons are swept toward the drain, producing a leakage current even though the transistor is OFF.

### Characteristics of GIDL

- Increases with **higher drain voltage (VDS)**.
- Increases with **thinner gate oxides**.
- Becomes more significant in **deep-submicron and nanometer CMOS technologies**.
- Strongly depends on the electric field at the gate-drain edge.
- Exists even when the transistor is nominally OFF.

![](https://cdn-images-1.medium.com/max/1200/1*Ro4dDPmZIYcsfgUEP5r_ww.png)

### Why GIDL Matters

In modern CMOS technologies, GIDL contributes to:

- **Static power consumption**
- **Memory cell data retention issues** (especially DRAM and SRAM)
- Reduced battery life in portable devices
- Reliability concerns in scaled transistors

### Methods to Reduce GIDL

- Use **lighter drain electric fields** (e.g., LDD structures).
- Increase gate oxide thickness (where possible).
- Employ **high-k gate dielectrics**.
- Optimize gate-drain overlap.
- Use advanced device structures such as FinFET and Gate-All-Around FET, which provide better electrostatic control.

### Simple Intuition

Think of GIDL as an **electric-field-induced tunneling current near the drain edge**. Even though the MOSFET channel is OFF, the extremely strong gate-to-drain field creates charge carriers through tunneling, allowing current to flow where ideally there should be none.

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Gate-Induced%20Drain/image.png)