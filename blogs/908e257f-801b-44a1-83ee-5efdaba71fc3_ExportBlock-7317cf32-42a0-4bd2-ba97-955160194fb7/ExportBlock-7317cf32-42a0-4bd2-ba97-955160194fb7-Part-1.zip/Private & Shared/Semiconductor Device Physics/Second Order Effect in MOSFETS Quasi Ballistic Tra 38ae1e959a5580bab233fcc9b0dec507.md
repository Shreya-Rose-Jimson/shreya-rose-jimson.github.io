# Second Order Effect in MOSFETS: Quasi Ballistic Transport

### 

![](https://cdn-images-1.medium.com/max/1200/1*iFaCTiEpDLUL003e8-__VQ.gif)

Imagine releasing a perfectly waxed sled at the top of a pristine, icy hill. For the first few fractions of a second, the sled simply accelerates downward under the pure influence of gravity, completely unhindered by any rough patches or friction. It is only after traveling some distance that the sled finally hits a bump or a patch of dirt and its pure acceleration is interrupted. In the magnificent world of nanoscale device physics, this exact phenomenon applies to our electrons and is called **quasi-ballistic transport**.

![](https://cdn-images-1.medium.com/max/1200/1*R107yyrCFONf4oZiSDBVNQ.gif)

**The Short-Time and Short-Distance Reality**

Normally, when carriers are injected into a region with an electric field, they constantly collide with lattice vibrations (phonons) and impurities, resulting in a steady-state drift velocity. However, in the extremely short-time or short-spatial-dimension regime, carriers move quasi-ballistically. This means they move either with an initial injection velocity or under the direct acceleration of the electric field. The absolute time limit over which this beautiful, unscattered behavior occurs is essentially the momentum relaxation time. If the device is shorter than the distance an electron can travel in this time, the electron simply zips through without scattering!

**The Critical Length Scales**

To rigorously define this regime, we must look at the mean free path. We define the quasi-ballistic regime as the domain of nearly free, unscattered carriers, where the inelastic mean free path serves as the critical length scale.

Consider a quantum wire with a width *W*. If we fabricate the wire such that the elastic mean free path (*le*) is vastly greater than the width (*le*≫*W*), we enter what physicists call the “pure metal” or pure quasi-ballistic regime. In this spectacular state, bulk scattering is exceptionally weak, and any diffusive process is overwhelmingly dominated simply by the carriers bouncing off the physical surfaces of the wire.

**The Temperature Dependence**

Temperature plays a massive role in whether a device operates diffusively or quasi-ballistically. At high temperatures, strong lattice vibrations ensure that devices remain firmly in the diffusive limit, meaning their longitudinal resistance is proportional to the wire length. However, as the temperature is dramatically lowered, this length dependence becomes “quenched” and the transport itself becomes more quasi-ballistic.

**The Terrifying Consequence for Transistors**

While quasi-ballistic transport sounds like a dream for pure speed, it actually presents a terrifying mathematical reality for transistor designers! In a traditional MOSFET, scattering occurring in the region between the space-charge layer and the drain provides a crucial screening effect.

However, when we aggressively shrink the channel and lose this scattering, the transport becomes quasi-ballistic. As this quasi-ballistic transport emerges, the transistor transitions to exhibiting triode-like characteristic curves, accompanied by a severe reduction in the output drain resistance. The magnificent saturation we rely on for digital logic disappears!

Sources:

1. Transport in Nanostructures, by David K Ferry; Stephen Marshall Goodnick; Jonathan P Bird