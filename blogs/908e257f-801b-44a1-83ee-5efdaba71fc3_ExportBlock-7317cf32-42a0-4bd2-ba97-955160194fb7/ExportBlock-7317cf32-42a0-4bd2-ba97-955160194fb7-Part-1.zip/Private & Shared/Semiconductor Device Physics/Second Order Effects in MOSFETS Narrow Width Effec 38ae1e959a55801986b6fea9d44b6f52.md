# Second Order Effects in MOSFETS: Narrow Width Effect

Imagine pressing a heavy, perfectly rectangular metal stamp (the gate) into a block of soft clay (the silicon substrate). You want to compress the clay directly beneath the stamp to a certain depth.

![](https://miro.medium.com/v2/resize:fit:519/1*RKG4NU5L23I4la4b1NCidw.png)

[https://www.dreamstime.com/photos-images/pottery-shape.html](https://www.dreamstime.com/photos-images/pottery-shape.html)

If your stamp is immensely wide, the vast majority of your effort goes strictly into pushing the clay directly underneath it. However, at the very edges of the stamp, the clay “bulges” outward and downward, meaning you are accidentally compressing a little bit of extra clay outside the boundary of the stamp. If you switch to an exceptionally narrow stamp, that tiny “extra” rim of clay at the edges suddenly becomes a massive percentage of the total clay you are displacing! Therefore, to achieve the exact same depth of compression, you must push *harder* per unit area than you did with the wide stamp.

**Oxide Encroachment and Fringing Fields**

In our ideal, one-dimensional mathematical models, we pretend the gate electric field points perfectly straight down into the silicon, acting only on the rectangular channel area exactly beneath it.

[](https://miro.medium.com/v2/resize:fit:398/0*XBUDlUhXMX4Mj-Cf)

[https://www.electronics-notes.com/articles/electronic_components/fet-field-effect-transistor/mosfet-metal-oxide-semiconductor-basics.php](https://www.electronics-notes.com/articles/electronic_components/fet-field-effect-transistor/mosfet-metal-oxide-semiconductor-basics.php)

In physical reality, the ultra-thin gate oxide does not simply vanish at the edges of the drawn channel width, *W*; rather, it transitions gradually into a much thicker insulator known as the field oxide. Because of this geometric transition, the electric field lines “fringe” or encroach outward laterally beyond the strict drawn width of the channel.

![](https://miro.medium.com/v2/resize:fit:750/1*CZdNmrE316smBESDBz_sww.gif)

[https://www.tandfonline.com/doi/full/10.1080/00207217.2011.629215](https://www.tandfonline.com/doi/full/10.1080/00207217.2011.629215)

What does this mean for the transistor? To reach the threshold of strong inversion, the gate must repel the majority holes and uncover a region of immobile, negatively charged acceptor ions in the p-type substrate. Because the electric field fringes outward at the edges, it uncovers an **additional space charge (depletion) region** at both lateral ends of the channel width. The gate is now forced to carry the extra burden of depleting this fringing charge, Δ*QB*, in addition to the ideal bulk charge, *QB*0.

**Calculating the Extra Burden**

Let us translate this beautiful geometry into rigorous mathematics. The total bulk charge *Q_B* the gate must deplete is the sum of the ideal charge and the extra edge charge:

*Q_B*=*Q_B*0+Δ*Q_B*

For a uniformly doped p-type semiconductor biased exactly at the threshold inversion point, the ideal bulk charge is simply a rectangular box of volume *W*⋅*L*⋅*x_dT*, which yields: *Q_B*0≈*eNaWLx_dT*

where *e* is the elementary charge,

*Na* is the acceptor doping concentration,

*L* is the channel length,

and *xdT* is the maximum vertical depletion width at threshold.

Now, we must model the additional charge from the two fringing edges. We can capture this rigorously using a dimensionless fitting parameter, *ξ*, which accounts for the exact shape of the lateral space charge spread. If we model the lateral spread of these fringing fields as perfect semicircles at both edges, this parameter is exactly *π*/2. This extra bulk charge is mathematically defined as:

Δ*Q_B*=*eNaLx_dT*(*ξx_dT*)

If we substitute these two pieces into our total charge equation and factor out the ideal charge, we arrive at a profound new expression:

*QB*≈*eNaWLx_dT*(1+*Wξx_dT*)

**The Threshold Voltage Shift**

Look very closely at the corrective term inside the parentheses: *Wξx_dT*. As long as the channel width *W* is macroscopic and massive compared to the microscopic depletion depth *x_dT*, this fraction is essentially zero, and the effect is totally invisible.

But as we shrink *W* down to the nanoscale level, this extra fringing charge becomes a massive percentage of the total work the gate must do. Because the gate has to “lift” a greater total amount of bulk charge to reach the threshold inversion point, the required gate voltage must physically *increase*.

We calculate this precise threshold voltage shift (Δ*V_T*) for an NMOS device by taking that extra bulk charge and dividing it by the oxide capacitance (*Cox*):

![](https://miro.medium.com/v2/resize:fit:428/1*wFJCmAnSg6L56hHu68j0og.png)

**The Ultimate Takeaway**

The physics speak to us through the math: because *W* is in the denominator, as the width of your transistor becomes smaller, the shift in the threshold voltage becomes aggressively larger. Furthermore, this shift is strictly in the **positive** direction for an n-channel MOSFET.

Sources:

1. Advanced Theory of Semiconductor Devices , by Karl Hess
2. [Semiconductor physics and devices](https://www.google.com/search?sca_esv=705a835819889e5e&sxsrf=ANbL-n7aYrLWqTdIrku90Da91GcZtnfZ9Q%3A1781235278720&q=Semiconductor+physics+and+devices&si=AL3DRZER-DkoldbnWY7HDlKGRpD8dJgm1uCz91Mtc2jZR9ngwCV-3g62fSctKw9es0BtEOqPGh71hKE1suXvDom2akG4Ee4cgSdy6-C80a1yEcPdDpY9P7E3r0gq7Dita7EKYmrw4gXrBBwi3k6Cr7FinK35WJlcAHiqE3v8uYo3w4YI8UMcQ9g%3D&sa=X&ved=2ahUKEwjEpbLA4oCVAxVTbmwGHVmLMbkQ_coHegQIFhAB&ictx=0), by Donald A. Neamen
3. [https://www.dreamstime.com/photos-images/pottery-shape.html](https://www.dreamstime.com/photos-images/pottery-shape.html)
4. [https://www.electronics-notes.com/articles/electronic_components/fet-field-effect-transistor/mosfet-metal-oxide-semiconductor-basics.php](https://www.electronics-notes.com/articles/electronic_components/fet-field-effect-transistor/mosfet-metal-oxide-semiconductor-basics.php)
5. [https://www.tandfonline.com/doi/full/10.1080/00207217.2011.629215](https://www.tandfonline.com/doi/full/10.1080/00207217.2011.629215)