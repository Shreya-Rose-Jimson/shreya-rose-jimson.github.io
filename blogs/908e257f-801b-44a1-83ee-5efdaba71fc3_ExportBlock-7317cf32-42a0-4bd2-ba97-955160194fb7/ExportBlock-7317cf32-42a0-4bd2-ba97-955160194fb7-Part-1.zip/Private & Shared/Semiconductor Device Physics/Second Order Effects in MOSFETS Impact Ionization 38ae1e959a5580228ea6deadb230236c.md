# Second Order Effects in MOSFETS: Impact Ionization

### 1. Introduction: The High-Energy World of Semiconductors

To the casual observer, a semiconductor is a silent, static component — a tiny “brick” in the vast architecture of the digital age. Yet, to a physicist, the interior of a silicon wafer is a violent, high-speed marketplace of energy. Within the crystal lattice, charge carriers are in a state of perpetual motion, governed by the laws of quantum mechanics and the dictates of external electric fields. To truly master device performance, we must look beyond the resting state and observe what happens when an electron gains an extreme, perhaps even dangerous, amount of energy.

Consider the physics of a high-speed billiard break. A gentle tap might nudge a single ball into a new position. However, if you strike the cue ball with immense force, it can scatter the entire rack, initiating a cascade where one moving object suddenly creates a dozen. In solid-state electronics, this “hard hit” is known as **Impact Ionization**. It is a fundamental generation process where a high-energy carrier triggers a chain reaction, fundamentally shifting the material’s electrical behavior from controlled conduction to a powerful, and sometimes destructive, multiplication of charge.

![](https://cdn-images-1.medium.com/max/1200/1*NZB1UbZp-7dIi1AI0iVAEw.gif)

### 2. The Physics of the “Chain Reaction”

Impact ionization is a mechanical result of kinetic energy transfer. Within a semiconductor, charge carriers — electrons and holes — drift through the periodic potential of the crystal lattice. Under standard conditions, these carriers move predictably. However, when subjected to a sufficiently high electric field, a carrier can become “hot,” gaining kinetic energy far exceeding the thermal average of its environment.

As outlined in the fundamental study of generation processes, the “chain reaction” follows a precise sequence:

- **The High-Field Collision:** A high-energy electron in the conduction band, accelerated by an intense electric field, strikes a valence electron bound to an atom in the crystal lattice.
- **The Energy Transfer:** During this collision, the “hot” carrier transfers a portion of its kinetic energy to the bound electron. If this energy exceeds the material’s threshold, it knocks the valence electron across the forbidden gap.
- **The 1-to-3 Multiplication:** This single event creates a new electron-hole pair. Where there was originally only one high-energy carrier, there are now three active participants: the original electron (now at a lower energy state), the newly liberated conduction electron, and the “hole” left behind in the valence band.

This multiplication effect represents a critical engineering trade-off. While it is the essential mechanism behind the high-sensitivity amplification found in avalanche photodiodes — the very technology that powers long-distance fiber-optic internet — it is also the harbinger of “avalanche breakdown.” If the field is not meticulously managed, this chain reaction can lead to a runaway surge of current that “bricks” a microprocessor, permanently damaging the delicate internal structures.

### 3. Energy Bands: The Barriers to Impact

Impact ionization is not a random occurrence; it is a threshold-dependent event governed by the material’s energy band structure. Electrons within a crystal occupy specific energy states, and the gap between these states dictates the “price of admission” for ionization.

- **The Band Gap Hurdle (E_g):** To trigger ionization, an electron must possess kinetic energy at least equal to the Band Gap Energy. This is the energy required to transition a carrier from the valence band to the conduction band.
- **Material Selection:** The specific architecture of the energy bands is determined by the material’s crystal structure.

“Crystal structure is of central interest because it is intimately tied to the intrinsic electrical properties exhibited by a material.” — Robert F. Pierret, *Advanced Semiconductor Fundamentals*

In the modern commercial landscape, Silicon (Si) “totally dominates” the market, as noted in the industry-standard literature. Its stability and the advanced state of its fabrication make it the ideal candidate for the vast majority of integrated circuits, microprocessors, and automotive ignition modules. In contrast, materials like Gallium Arsenide (GaAs) are reserved for niche, high-performance applications — such as laser diodes and high-speed integrated circuits — where superior transport properties and specific optoelectronic transitions are required.

### 4. From Equilibrium to “High-Field” Effects

Most foundational physics assumes a state of “Equilibrium” — a stable condition where carrier concentrations (n and p) are defined by the Fermi Function and the Density of States. Impact ionization, however, is a “High-Field Effect” that pulls the system violently away from equilibrium. It is a dynamic generation process that effectively rewrites the carrier statistics of the device.

To visualize the transition from a resting state to a dynamic one, we can compare the two regimes:

- **Equilibrium Carrier Statistics (The Resting State):**
- The system is thermally stable with no high external voltage.
- Carrier concentrations remain constant over time.
- Transport is governed by simple drift and diffusion.
- 
- **Recombination-Generation Processes (The Dynamic State):**
- High electric fields push carriers toward “velocity saturation.”
- Impact ionization actively creates new carriers, moving the system away from equilibrium.
- Under extreme conditions, “ballistic transport” may occur, where carriers move through the lattice without significant scattering.
- 

### 5. The Nanostructure Perspective: Scaling the Impact

As the semiconductor industry pushes toward nanometer-scale dimensions, the physics of impact ionization enters the mesoscopic regime. In these ultra-small environments — incorporating self-assembled nanowires, nanotubes, and quantum dots — the traditional rules of bulk transport begin to fail.

The primary challenge of device scaling is the increase in the electric field (E). Because the electric field is a function of voltage over distance (E = V/d), shrinking the distance (d) while maintaining operational voltages causes the field to skyrocket. In a nanoscale transistor, an electron may experience a field so intense that it undergoes “ballistic transport,” flying across the device with its full energy intact.

When these high-energy carriers eventually collide with the lattice, the resulting impact ionization is significantly more concentrated. This creates a “scaling wall” for the industry: engineers must find ways to harness the speed of high-energy transport without allowing the resulting ionization to trigger breakdown in circuits that are only a few atoms thick.

### 6. Conclusion: The Future of High-Power Performance

Mastering the “generation-recombination” processes of solid-state physics is the key to the next generation of high-power performance. Our understanding of impact ionization is the reason modern technology can handle the immense energy demands of everything from high-speed microprocessors to the heavy-duty ignition modules in electric vehicles.

As we continue to push the boundaries of how small and fast our technology can go, we face a recurring question: Will we ever find a way to perfectly tame the high-energy chaos of impact ionization, or is it a fundamental physical limit we must learn to dance with? Whether we are designing the next iteration of Silicon-based logic or exploring the frontiers of nanostructure transport, the “spark inside” remains the most critical force we have to master.