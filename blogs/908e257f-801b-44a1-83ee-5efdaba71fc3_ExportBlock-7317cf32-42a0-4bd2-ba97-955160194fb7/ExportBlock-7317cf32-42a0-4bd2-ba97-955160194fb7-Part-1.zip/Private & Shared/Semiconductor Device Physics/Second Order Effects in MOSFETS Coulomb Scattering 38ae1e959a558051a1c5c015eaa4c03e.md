# Second Order Effects in MOSFETS: Coulomb Scattering

Imagine driving a highly magnetic sports car (an electron) down a highway scattered with giant electromagnets (ionized impurities). If you drive slowly, the electromagnets easily pull you off course. But if you floor the accelerator, you zip past them so quickly that they barely have time to deflect your path!

This perfectly captures the essence of **Coulomb scattering** — frequently referred to as ionized impurity scattering — which is a dominant mechanism limiting electron mobility at low temperatures.

**1. The Physical Reality: The Screened Potential**

When we intentionally introduce dopant atoms into a semiconductor crystal, they ionize and leave behind fixed, charged cores. The bare electrostatic potential of such an impurity is a long-range Coulomb potential.

However, we must remember that this ion sits in a sea of free electrons. These mobile electrons form a repulsive cloud around the positive ion, effectively shielding its full attractive force. We mathematically define this *screened Coulomb potential* as:

![](https://miro.medium.com/v2/resize:fit:335/1*lIP0qZ1H6cvSWyxfoTfPRw.png)

where *ϵ* is the dielectric constant of the semiconductor, and *λ* is the inverse screening length (related to the Debye length). This parameter *λ* is elegantly defined by :

![](https://miro.medium.com/v2/resize:fit:590/1*en1jn4GCusLr8CwezG2gdw.png)

with *n* being the free electron density.

**2. The Mathematical Elegance: Fermi’s Golden Rule**

To find exactly how often our electron is knocked off its trajectory, we turn to the magnificent Fermi’s Golden Rule. We must calculate the matrix element, which dictates how strongly the potential couples the initial electron state **k** to the final state **k**′. For Coulomb scattering, this matrix element is fundamentally tied to the Fourier transform of our screened potential.

When we carry out the quantum mechanical integration, the resulting scattering rate *W*(*k*) for an electron with momentum ℏ*k* and energy *E_k* is derived as:

![](https://miro.medium.com/v2/resize:fit:594/1*dGSSLEuZOqP5VVFcSADS9Q.png)

where the prefactor *F* depends on the density of states *N*(*E_k*) and the ionized impurity density *N_I*:

![](https://miro.medium.com/v2/resize:fit:486/1*SBFO8opxQ6LRryPrunC6DA.png)

Because this is an elastic collision (the heavy impurity doesn’t absorb energy), the energy before and after the collision remains unchanged, and only the momentum shifts.

**3. The Macroscopic Consequence: The Temperature Paradox**

Here is where the mathematics reveals a beautiful physical paradox! For most scattering mechanisms (like bumping into vibrating lattice atoms, known as phonon scattering), heating up the crystal makes the scattering *worse*, causing mobility to drop.

But Coulomb scattering is unique. As the temperature increases, the random thermal velocity of the electron increases. Returning to our sports car analogy, because the electron is moving so fast, it spends significantly less time in the vicinity of the ionized impurity’s Coulomb force. The less time it spends near the force, the smaller the deflection.

Mathematically, the mobility limited by Coulomb scattering (*μI*) scales exactly with the temperature to the three-halves power:

![](https://miro.medium.com/v2/resize:fit:249/1*wOgmHxZUTHG9aozPxvrw9g.png)

At low temperatures, Coulomb scattering completely dominates and severely degrades device mobility, but as the device warms up, its effect dynamically fades away.