# Second Order Effects in MOSFETS: Velocity Saturation

Imagine an object falling through the Earth’s atmosphere. Gravity pulls it down, causing it to accelerate, but the frictional force of the air pushing back eventually balances the pull of gravity, forcing the object to attain a strict terminal velocity. In the wondrous world of semiconductor physics, our electrons are the falling objects, the electric field is gravity, and the microscopic lattice collisions act as the atmosphere.

**1. The Physical “Speed Limit”**

In our classical, low-field models, an electron’s average drift velocity (*vd*) increases linearly with the applied electric field (E), governed gracefully by the carrier mobility (*μ*).

However, as we aggressively shrink the channel length of our transistors to submicron dimensions, the lateral electric field across the channel becomes absolutely colossal, easily exceeding 104 to 105 V/cm. At these extreme fields, the linear relationship completely breaks down. The electrons are driven so hard that they collide far more frequently with the vibrating crystal lattice, dumping their kinetic energy. Because of this intense scattering, the electrons simply cannot accelerate any further and reach a strict “terminal speed” known as the saturation velocity (*vsat*). In silicon at room temperature, this universal speed limit is approximately 107 cm/s.

**2. The Mathematical Metamorphosis**

When the velocity of our carriers “hits a wall,” it completely rewrites the calculus of our MOSFET I-V characteristics:

- **Premature Saturation:** Because the electrons reach their absolute speed limit so early, the drain current reaches its maximum value prematurely. This means the transistor enters the saturation region at a drain-to-source voltage (*VDS*) much lower than the classical pinch-off point of *VGS*−*VTH.*
- **The Shift to Linearity:** Since steady-state current is fundamentally the product of charge density and velocity, locking the velocity at *vsat* fundamentally changes the transistor’s identity. In the extreme case of complete velocity saturation, the classic square-law equation for drain current collapses into a strictly **linear** function of the overdrive voltage:

![](https://cdn-images-1.medium.com/max/1200/1*kBpxAQtfmkVYpwNlKHt7tQ.png)

The dependence on the channel length (*L*) has completely vanished from the formula.

- **Transconductance Flatlines:** Transconductance (*gm*) measures the sensitivity of the transistor. If we take the derivative of our new linear current equation with respect to *VGS*, the overdrive voltage drops out entirely, leaving us with:

![](https://cdn-images-1.medium.com/max/1200/1*-sqrRF7PfT9PfRBvDm5yXQ.png)

This reveals a harsh mathematical reality for analog designers: the transconductance is now a constant value. No matter how much harder you drive the gate voltage, you cannot squeeze any more transconductance out of the device.

**3. The Bizarre Exception: Gallium Arsenide (GaAs)**

I must share a phenomenal quirk of quantum mechanics! In certain materials like Gallium Arsenide, the velocity-field relationship is not simply a curve that flattens out. As the electric field increases, electrons in the lowest energy band (the Γ-valley) gain enough energy to physically transfer into a higher-energy secondary valley (the L-valley).

Because the effective mass of the electron in this upper valley (0.55*m*0) is almost an order of magnitude larger than in the lower valley (0.067*m*0), the electron’s mobility drops drastically. Consequently, the drift velocity actually *decreases* as the electric field increases, creating a region of **negative differential mobility** before it finally saturates. Circuit designers brilliantly exploit this “retrograde” velocity behaviour to build microwave frequency oscillators.

Sources:

1. Advanced semiconductor fundamentals, by Robert F. Pierret
2. Semiconductor physics and devices, by Donald A. Neamen
3. Design of Analog CMOS Integrated Circuits, by Behzad Razavi