# Second Order Effects in MOSFETS: Junction Leakage

### Second Order Effects in MOSFETS: Junction leakage

![](https://cdn-images-1.medium.com/max/1200/1*FV5cKIXFz6CWizTQsb7plw.gif)

Imagine a beautifully engineered, high-pressure plumbing system where separate pipes (the source and drain) are routed through a massive underground reservoir (the substrate). To keep water from leaking out of the pipes into the reservoir, you install heavy-duty pressure seals (reverse-biased diodes) that are supposed to block exactly 100% of the water. But nature is rarely perfect. Because the environment is warm, every so often, the thermal energy spontaneously condenses a brand new drop of water directly *inside* the seal itself, creating a tiny, continuous, unavoidable drip.

**1. The Structural Necessity of Reverse Bias**

In an NMOS transistor, the heavily doped *n*+ source and drain terminals are embedded within a *p*-type semiconductor substrate. For the transistor to function and effectively isolate the source and drain from each other, the *pn* junctions formed between these terminals and the substrate must remain completely reverse-biased under all operating conditions.

Ideally, we pretend that a reverse-biased *pn* junction acts as a perfect brick wall, dropping the current to absolute zero so that the drain current is entirely controlled by the gate. However, the laws of thermodynamics refuse to be locked out!

**2. The Quantum “Leak” (Thermal Generation)**

To understand the leak, we must look microscopically at the space charge (depletion) region of these reverse-biased source and drain junctions. Because the built-in and applied electric fields sweep carriers away, this region is essentially starved of mobile charges, meaning the electron concentration (*n*) and hole concentration (*p*) are driven close to zero (*n*≈*p*≈0).

According to the Shockley-Read-Hall recombination theory, when we completely evacuate the mobile carriers, the mathematical recombination rate *R* becomes *negative*. A negative recombination rate is physically a **generation rate**! Because the temperature of the crystal is above absolute zero, thermal energy continuously shakes the silicon lattice, spontaneously tearing electrons out of the valence band and elevating them into the conduction band directly inside the depletion region.

**3. The Mathematical Elegance of the Drip**

The massive electric field inside the reverse-biased space charge region instantly catches these newly born electron-hole pairs. It violently sweeps the electrons into the *n*+ drain or source, and the holes into the *p*-type substrate, creating a continuous, parasitic leakage current.

We do not just observe this leak; we can calculate it exactly! The thermal generation rate of these carriers is precisely 2*τ*0*ni*, where *ni* is the intrinsic carrier concentration and *τ*0 is the minority carrier lifetime. By integrating this generation rate over the entire width (*W*) of the depletion region, we arrive at the spectacular equation for the reverse-biased generation current density (*Jgen*):

![](https://cdn-images-1.medium.com/max/1200/1*kHXylHPAICOIK6rM0qoQFA.png)

where *e* is the elementary charge.

**4. The Macroscopic Consequence**

Why does this mathematical reality terrify integrated circuit designers? Because for a silicon *pn* junction at room temperature, this thermal generation current is roughly four orders of magnitude *larger* than the ideal theoretical reverse-saturation current (*Js*)!

The generation current is the absolute dominant source of reverse-biased leakage in a silicon diode. In modern microprocessors containing billions of MOSFETs, all of these reverse-biased source and drain junctions are constantly leaking this tiny *Jgen* into the substrate, accumulating into a massive drain on the battery even when the processor is entirely idle. It is so critical that in our rigorous SPICE models, we must explicitly account for this physical limit using the parameter `JS`, representing the source/drain leakage current per unit area.

Sources:

1. Design-of-Analog-CMOS-Integrated-Circuits, by Behzad Razavi
2. Semiconductor physics and devices, by Donald A. Neamen