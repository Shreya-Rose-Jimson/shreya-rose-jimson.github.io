# Second Order Effects in MOSFETS: Subthreshold Conduction

When the operator completely lifts the gate (turning the transistor fully “ON”), water rushes through effortlessly. But what happens when the gate is slammed completely “shut”? In a perfect, classical world, the flow drops to exactly zero. However, in the microscopic reality of thermodynamics, the water boils and churns. A tiny, exponentially small fraction of the water molecules possess enough thermal energy to splash right over the top of the closed dam!

This beautiful, “leaky” quantum reality is what we call **Subthreshold Conduction** in a MOSFET

![](https://cdn-images-1.medium.com/max/1200/1*j1IpzDxNT7FokbYtuAV5gA.gif)

**1. The Physical Reality: Weak Inversion and Diffusion**

In our classical models, we pretend that if the gate-to-source voltage (*VGS*) is strictly less than the threshold voltage (*VTH*), the drain current (*ID*) is zero. However, before reaching the threshold inversion point, the semiconductor surface still possesses a small amount of induced charge. This regime is formally known as **weak inversion**, defined mathematically as the point where the surface band bending (*ψs*) is strictly between the bulk Fermi potential (*ϕF*) and twice the bulk Fermi potential (2*ϕF*).

Because the inversion charge density is incredibly small in this regime, the lateral electric field along the channel is practically nonexistent, meaning the standard *drift* current we rely on in strong inversion drops to zero. Instead, the electrons rely entirely on **diffusion** to cross from the source to the drain. The electrons “diffuse” down the concentration gradient, making the MOSFET operate almost identically to the base region of a forward-biased Bipolar Junction Transistor (BJT).

**2. The Mathematical Elegance: The Exponential Law**

Because the transport mechanism has shifted purely to thermal diffusion, the mathematics completely metamorphose. The current no longer follows the classic quadratic “square-law”. Instead, it exhibits a spectacular **exponential** dependence on the gate-to-source voltage.

For a device operating in the subthreshold regime, the rigorous equation for the drain current is:

![](https://cdn-images-1.medium.com/max/1200/1*fDerYc0A1autPDmxaEA17w.png)

where *kT*/*e* (or *VT*) is the thermal voltage (approx. 26 mV at room temperature), and *ξ* is a nonideality factor greater than 1.

Look closely at the second bracketed term involving the drain-to-source voltage (*VDS*). If *VDS* is larger than just a few thermal voltages (roughly >100 mV), the exponential term exp(−*eVDS*/*kT*) vanishes into nothingness. The subthreshold current suddenly becomes completely independent of *VDS*! The equation elegantly collapses to:

![](https://cdn-images-1.medium.com/max/1200/1*hvy6Ce1jIl_s25epTH-6BA.png)

where *I*0 is a proportionality constant.

**3. The Subthreshold Slope: Measuring the “Leak”**

As circuit designers, we desperately want to know: *How hard do I have to pull the gate voltage down to choke off this exponential leak?*

We measure this using the **subthreshold slope**, which is the inverse of the slope of log10(*ID*) versus *VGS*. Ideally, if the nonideality factor *ξ*=1, the math dictates that a decrease of exactly **60 millivolts** in the gate voltage will reduce the subthreshold current by one decade (a factor of 10) at room temperature.

However, in reality, *ξ* is heavily dependent on the ratio of the depletion capacitance to the oxide capacitance (*ξ*=1+*Cd*/*Cox*), as well as the density of microscopic interface states. Because of this, it typically takes roughly **80 mV/decade** to shut off the device.

**The Grand Consequence: The Power Dissipation Nightmare**

Why do we care about this microscopic leak? Let us do the math on a modern microprocessor!

If a transistor requires 1*μ*A to be considered “ON” at threshold, and we scale our threshold voltage down to 0.3 V to save dynamic power, what happens when we apply 0 V to the gate to turn it “OFF”? With an 80 mV/decade slope, dropping 0.3 V only reduces the current by a factor of 103.75≈5620.

The single “OFF” transistor is still leaking roughly 0.18 nA. That sounds tiny until you remember a modern chip contains *hundreds of millions* of these transistors. Suddenly, your chip is leaking amperes of current and dissipating massive amounts of static power even when it is sitting completely idle doing nothing.

Sources:

1. Semiconductor physics and devices, by Donald A. Neamen
2. Design of Analog CMOS Integrated-Circuits, by Behzad Razavi