# Second Order Effects in MOSFETS: Band-to-band tunneling (BTBT)

### 

![](https://cdn-images-1.medium.com/max/1200/1*xsiNgJjx5XO3YF_JBD2erw.gif)

Imagine you are a prisoner trapped behind a massive, towering concrete wall (the forbidden energy bandgap of a semiconductor). Classically, the only way to escape is to somehow acquire enough energy to climb entirely over the top of the wall. But quantum mechanics offers a spectacular loophole: if the wall is squeezed until it is incredibly thin, you do not need to climb it. You can simply step *through* the solid concrete and instantly materialize on the other side!

This breathtaking quantum phenomenon is known as **Band-to-Band Tunneling (BTBT)**, frequently referred to in specific junction geometries as Zener tunneling.

**1. The Physical Setup: Bending the Bands**

In a normal, thick semiconductor region, the valence band (filled with trapped electrons) and the conduction band (filled with empty states) are separated by the forbidden energy gap (*Eg*). Electrons simply do not have the energy to cross this void.

However, consider what happens in the presence of an incredibly strong electric field — such as in a heavily doped, reverse-biased *p*−*n* junction, or within the high-field drain region of a scaled MOSFET. This massive electric field violently bends the energy bands. If the field is strong enough, the bands tilt so steeply that the valence band edge on one side of the space charge region is physically pulled up *higher* than the conduction band edge on the other side.

Suddenly, an electron residing in the valence band finds itself horizontally adjacent to a completely unoccupied state in the conduction band, separated only by a microscopically thin triangular potential barrier.

**2. The Quantum Mathematics: The Probability of the Leap**

Because electrons possess a wave nature, their wavefunctions do not simply stop at the barrier; they decay exponentially into the forbidden gap. If the barrier is thin enough, the tail of the wavefunction penetrates all the way through, allowing the electron to materialize in the conduction band.

We can calculate the exact probability (*T*) of this tunneling event using the WKB (Wentzel-Kramers-Brillouin) approximation for a triangular barrier. The transmission probability is elegantly defined as:

![](https://cdn-images-1.medium.com/max/1200/1*YBgE_TySeC4offGDtOdDDQ.png)

where *m*∗ is the reduced effective mass of the electron-hole system, *Eg* is the bandgap energy, *e* is the elementary charge, ℏ is the reduced Planck constant, and *E* is the applied electric field.

Look closely at the denominator of the exponent: the electric field *E*. A tunneling probability of approximately 10−6 is required to start a massive breakdown process. In materials like silicon or gallium arsenide, this requires colossal electric fields, typically on the order of 106 V/cm. As *E* increases, the negative exponent shrinks, and the tunneling probability skyrockets exponentially.

**3. The Consequence in MOSFETs: The Nanoscale Leak**

Why does this quantum physics keep modern MOSFET designers awake at night?

As we aggressively shrink our transistors to the nanometer scale, we are forced to use extremely heavy doping concentrations (like the halo implants we discussed previously) to maintain gate control. Heavy doping leads to vanishingly thin depletion widths. Because the electric field is inversely proportional to the depletion width (*E*∝*V*/*W*), these scaled devices naturally develop immense built-in electric fields.

When a MOSFET is turned off, the reverse-biased junctions at the source and drain are subjected to these massive fields. The valence electrons are violently torn from their atomic bonds and tunnel directly into the conduction band, leaving behind a hole. This generates an unrelenting reverse leakage current. 

Sources:

1. Advanced Theory of Semiconductor Devices , by Karl Hess
2. Semiconductor Device Physics and Design, by Umesh K Mishra, Jasprit Singh