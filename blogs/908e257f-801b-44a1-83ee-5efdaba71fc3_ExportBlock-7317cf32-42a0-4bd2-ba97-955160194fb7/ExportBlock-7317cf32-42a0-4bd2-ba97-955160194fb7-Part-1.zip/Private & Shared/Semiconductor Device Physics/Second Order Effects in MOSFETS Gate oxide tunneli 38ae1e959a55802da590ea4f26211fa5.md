# Second Order Effects in MOSFETS: Gate oxide tunneling

### 

![](https://cdn-images-1.medium.com/max/1200/1*T7ivtRX53PkrYdoEzEayyQ.gif)

Imagine you are trapped in a room with a thick concrete wall. Classically, you must climb over it to escape. But what if that wall were thinned down to the thickness of a single sheet of tissue paper? Quantum mechanics dictates that because you possess a wave nature, you have a non-zero probability of simply “ghosting” straight through that solid barrier!

This is the perfect intuition for **Gate Oxide Tunneling** in modern MOSFETs. Let us break down the beautiful quantum mechanics and the harsh engineering realities of this nanoscale leak.

**1. The Breakdown of the Classical Wall**

In a standard MOSFET, the gate dielectric (traditionally silicon dioxide, *SiO*2) is placed between the gate electrode and the semiconductor channel. Classically, this oxide is an impenetrable insulator; electrons in the gate or channel lack the thermal energy to overcome the massive potential barrier, meaning the gate current is assumed to be strictly zero.

However, as we relentlessly scale down transistors to increase speed and packing density, we are forced to shrink the gate oxide thickness (*tox*). When this barrier width becomes exceptionally thin — typically below 5 nanometers — the classical rules completely collapse, and electrons begin to tunnel directly through these classically forbidden regions.

**2. The Quantum Mathematics: WKB and Wave Penetration**

Because electrons are fundamentally matter waves, their wavefunctions do not abruptly vanish the moment they hit the oxide wall. Instead, the wavefunction decays exponentially inside the forbidden energy gap of the insulator.

If the oxide is thin enough, the tail of this wavefunction penetrates completely through the barrier and emerges on the other side. While the tunneling probability for a single electron might appear vanishingly small, if an enormous number of electrons constantly impinge on this potential barrier, a highly significant number will successfully penetrate it. We mathematically model this transmission probability using the WKB (Wentzel-Kramers-Brillouin) approximation or Non-Equilibrium Green’s Functions (NEGF).

Furthermore, early foundational work by Fowler and Nordheim mathematically described how a massive electric field across an insulator bends the energy bands into a sharp triangular shape, allowing for electric field-aided tunneling through thin insulating layers like our thermally grown oxides

**3. The Macroscopic Consequence: Unrelenting Gate Leakage**

When these electron waves materialize on the other side of the oxide, they form a continuous, parasitic current known as **gate leakage**.

This leakage can be severely exacerbated by short-channel effects. As the horizontal electric field in the channel accelerates carriers to blistering speeds, these “hot electrons” gain kinetic energy far exceeding thermal equilibrium. Because they are at a higher energy state, they face a physically “shorter” barrier, making them highly susceptible to being injected directly into the oxide and drastically increasing the tunneling gate current.

**4. The Engineering Triumph: High-***κ* **Dielectrics**

Here is the ultimate mathematical paradox transistor designers face: to maintain electrostatic control over the channel (high *Cox*), we must scale down the oxide thickness, but as scaling pushes *tox* below 1.5 nm, the direct tunneling current rapidly increases to catastrophic levels.

How do we defeat quantum mechanics? We change the material! The oxide capacitance per unit area is defined as:

![](https://cdn-images-1.medium.com/max/1200/1*s_GoiD9lqvG8ks83EWBw5A.png)

To maintain a large capacitance without shrinking the physical thickness *tox*, we replace the standard *SiO*2 with alternative **high-dielectric-constant (high-***κ***) insulators**. By massively increasing the permittivity (*ϵox*), we can utilize a physically *thicker* insulator. This thicker barrier beautifully suffocates the exponential tunneling probability, effectively mitigating gate leakage, while still providing the exact same, or even better, capacitive control over the channel.