# Second Order Effects in MOSFETS: Mobility Degradation

Imagine you are driving a sleek, high-speed sports car (an electron) down a wide, perfectly paved highway (the silicon channel). If you drive straight down the middle, you face very little resistance. Now, imagine a massive, invisible crosswind suddenly begins blowing from the side, violently pinning your car against a rough, bumpy concrete guardrail. No matter how hard you press the accelerator, the sheer friction of scraping against the guardrail slows you down entirely.

![](https://media4.giphy.com/media/v1.Y2lkPTc5NDFmZGM2bXRsNjltNjQ3a3V3ZTM5NDcwd3FjZW1wY3E3M3p5ZG5oNWZtancyaCZlcD12MV9naWZzX3NlYXJjaCZjdD1n/XTYhuf6DwbDri/giphy.gif)

This is the perfect intuition for **Mobility Degradation** in a MOSFET! Let us break down the physical mechanics and the beautiful mathematics of how a vertical electric field completely disrupts the transport of our carriers.

**1. The Physical Reality: Surface Scattering**

In a MOSFET, the inversion layer charge is naturally induced by a vertical electric field pointing from the gate into the substrate. A positive gate voltage creates an electrostatic force that pulls electrons from the source into the channel and toward the surface.

However, as we increase the gate-to-source voltage (*VGS*) to drive more current, this vertical electric field becomes absolutely enormous. This high electric field aggressively confines the charge carriers to an extremely narrow quantum well directly below the oxide-silicon interface. Because the electrons are pressed so tightly against the boundary, they violently collide with the microscopic, atomic-level bumps of the Si-SiO2 interface.

Furthermore, they are repelled by localized Coulombic forces from fixed oxide charges trapped in the dielectric. This phenomenon, formally known as **surface scattering**, brutally degrades the effective carrier mobility as the gate voltage increases.

**2. The Mathematical Elegance**

To integrate this physical reality into our circuit models, we must modify our constant "low-field" mobility (*μ*0). We can model the effective mobility (*μeff*) using a beautiful empirical equation:

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Mobility%20Degradati/image.png)

 where *θ* is a fitting parameter with dimensions of V−1.

Look closely at *θ*; it is roughly proportional to 10−7/*tox*. This tells us a profound scaling truth: as we shrink the oxide thickness (*tox*) in modern nanometer devices, the vertical electric field in the oxide becomes vastly stronger, making *θ* larger and the mobility degradation significantly more severe!

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Mobility%20Degradati/image%201.png)

 *further highlighting how strongly the field crushes the mobility.)*

**3. The Consequence: Reshaping the I-V Characteristic**

How does this degraded mobility alter our classical square-law drain current? Let us substitute our new *μeff* into the saturation current equation: 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Mobility%20Degradati/image%202.png)

 If we assume that the degradation is moderate, meaning *θ*(*VGS*−*VTH*)≪1, we can use a Taylor series expansion, (1+*x*)−1≈1−*x*, to rewrite the current: 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Mobility%20Degradati/image%203.png)

Look at the extraordinary result of this algebra! Because of mobility degradation, the *ID* characteristic completely deviates from a simple parabola. The vertical field actually introduces **third-order (odd) harmonics** into the drain current.

**4. The Impact on Transconductance (*gm*)**

For an analog circuit designer, the transconductance (*gm*) is the holy grail—it is the sensitivity of the transistor. In an ideal square-law device, *gm* increases linearly forever as we increase the overdrive voltage. But let us take the exact derivative of our mobility-degraded current with respect to *VGS*: 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Mobility%20Degradati/image%204.png)

As the overdrive voltage (*VGS*−*VTH*) becomes very large, the squared terms dominate, and the transconductance ceases to grow. It completely flattens out, asymptotically approaching a hard mathematical limit of approximately 

![image.png](Second%20Order%20Effects%20in%20MOSFETS%20Mobility%20Degradati/image%205.png)