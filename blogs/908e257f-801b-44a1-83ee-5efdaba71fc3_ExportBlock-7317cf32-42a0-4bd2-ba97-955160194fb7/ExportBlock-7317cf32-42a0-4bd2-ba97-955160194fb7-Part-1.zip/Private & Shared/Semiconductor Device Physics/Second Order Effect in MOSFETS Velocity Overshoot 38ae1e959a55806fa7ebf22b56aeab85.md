# Second Order Effect in MOSFETS: Velocity Overshoot

Imagine a high-performance dragster launching off the starting line. For the first few fractions of a second, before the engine overheats and before maximum aerodynamic drag can build up, the car accelerates purely based on the massive brute force of its engine, reaching a blistering top speed. But very quickly, the intense drag and internal friction catch up, forcing the car to slow down and settle into a lower, steady cruising speed.

![](https://cdn-images-1.medium.com/max/1200/1*cSnXz8-P0_MLjlMFiPOQ0Q.gif)

In semiconductor physics, our electrons are the dragsters, the applied electric field is the engine force, and the microscopic lattice collisions (scattering) act as the aerodynamic drag. This phenomenon — where an electron accelerates to a speed far exceeding its theoretical maximum steady-state limit before friction catches up — is exactly what we call **Velocity Overshoot**.

**1. The Physics of Delayed Scattering**

In our classical models of carrier drift, we assume the channel length (*L*) is vastly larger than the mean distance between scattering events (*l*). In this long-channel regime, electrons bump into vibrating lattice atoms constantly, achieving a steady-state average drift velocity.

However, when we apply a massive, rapidly rising electric field (such as a spatial step in the field near the drain), the electrons are violently accelerated forward. Because the electrons all start at roughly zero momentum (*k*=0), they initially travel completely in the forward direction without scattering. During this microscopic time window, the electrons behave like perfect projectiles, moving “ballistically” without experiencing a single collision. Because they temporarily avoid the friction of the lattice, their velocity spikes dramatically, outrunning the theoretical steady-state limits.

**2. The Mathematics of “Delayed Heating”**

We can rigorously explain this using the concept of electron temperature (*T_e*). Recall that as an electric field does work on an electron gas, the carriers become “hot,” meaning their average kinetic energy (*T_e*) rises. Because scattering becomes much more severe at higher energies, the effective carrier mobility (*μ*) strictly decreases as *T_e* increases.

As time goes on (typically a fraction of a picosecond), scattering events finally occur, randomizing the electrons’ momentum. The electron temperature catches up, the mobility crashes, and the velocity drops down to the standard saturation limit (*v_sat*≈10^7 cm/s). This entire transient speed burst typically resolves over incredibly short spatial distances, on the order of 500 to 5000 A˚.

**3. The Valley Transfer Phenomenon (The GaAs Miracle)**

The most spectacular physical manifestation of velocity overshoot occurs in III-V compounds like Gallium Arsenide (GaAs) and Indium Gallium Arsenide (InGaAs).

When electrons in GaAs are first subjected to the massive electric field, they reside in the Γ valley of the conduction band, where their effective mass is exquisitely small. Because of this tiny mass and the lack of immediate scattering, they accelerate to astonishing transient speeds, sometimes easily exceeding 4×10^7 cm/s in InGaAs High Electron Mobility Transistors (HEMTs).

However, as they accelerate, they gain an enormous amount of kinetic energy. Within a fraction of a picosecond, they acquire enough energy to physically scatter into the higher-energy *L* and *X* satellite valleys. Because the effective mass in these secondary valleys is drastically larger, the electrons suddenly slam into a metaphorical brick wall. Their velocity plummets, creating the sharp “peak” and subsequent drop characteristic of a velocity overshoot curve.

**The Grand Conclusion**

At macroscopic dimensions, velocity saturation is a hard limit. But as we shrink our devices — specifically when channel lengths drop below 0.1*μm* in silicon or 1*μm* in GaAs — we enter a regime where our carriers can literally outrun the statistical mechanics of scattering.

Sources:

1. Advanced semiconductor fundamentals, by Robert F. Pierret

2. Advanced Theory of Semiconductor Devices, by Karl Hess