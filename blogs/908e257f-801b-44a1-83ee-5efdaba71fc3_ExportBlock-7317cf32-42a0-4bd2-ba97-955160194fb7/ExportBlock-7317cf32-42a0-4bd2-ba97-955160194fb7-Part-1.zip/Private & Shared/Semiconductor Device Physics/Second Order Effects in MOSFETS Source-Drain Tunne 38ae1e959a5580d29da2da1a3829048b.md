# Second Order Effects in MOSFETS: Source-Drain Tunneling

Imagine two massive oceans of water (the source and the drain) separated by a thick, towering concrete dam (the channel region controlled by the gate). To get water from one side to the other when the gate is closed, you normally have to heat the water so a few energetic molecules splash over the top — a process we previously mapped out as thermal subthreshold leakage. But what if you shrink that dam until it is as thin as a single sheet of tissue paper? The water molecules no longer need to climb over the top; because of the laws of quantum mechanics, they simply “ghost” directly through the solid wall and materialize on the other side!

This is the perfect intuition for **Source-Drain Tunneling**. Let us break down the beautiful, yet terrifying, quantum mechanics of this ultimate scaling limit in our nanoscale MOSFETs!

**1. The Breakdown of the Classical Barrier**

In an ideal, macroscopic MOSFET operating in the “OFF” state, the channel acts as a potential energy barrier separating the source and the drain. Classically, an electron must acquire enough thermal energy to move over this barrier to create a current.

However, as we relentlessly scale down the dimensions of the transistor, the physical distance between the source and the drain becomes microscopically thin. When the physical width of this barrier shrinks below approximately 5 nm, electrons begin to tunnel directly through the classically forbidden regions of the channel.

**2. The Quantum Mechanics of the Leak**

To understand why this happens, we must abandon the idea of electrons as solid particles and treat their behavior strictly as quantum mechanical matter waves.

When an electron wave encounters the potential barrier of the “OFF” channel, it does not abruptly bounce backward. Instead, its wavefunction decays exponentially into the forbidden barrier region. If the channel is incredibly short, the tail of this exponential wavefunction penetrates completely through the channel and emerges in the drain. Because these electrons tunnel *through* the barrier instead of jumping *over* it, the classical drift-diffusion equations we rely on to model current entirely fail to predict the device’s behavior.

**3. The Macroscopic Consequence: The Temperature Paradox**

This quantum leap creates a catastrophic leakage current that flows between the source and drain even when the transistor is turned completely off.

Here is the most fascinating and devastating physical reality: unlike normal subthreshold conduction, which relies on the thermal energy of the lattice and can be frozen out at cryogenic temperatures, quantum tunneling is governed strictly by wave mechanics. Because of this, direct source-drain tunneling is an entirely temperature-independent phenomenon.

In laboratory measurements, as channel lengths are aggressively scaled below 2 nm, direct source-drain tunneling completely dominates the transport. This tunneling is so severe that it strictly prohibits the observation of normal nanowire or transistor switching effects.

**4. The Modeling Metamorphosis: NEGF**

How do physicists and engineers design circuits when the fundamental classical equations break down? We must elevate our mathematics to the **Non-Equilibrium Green’s Function (NEGF)** formalism.

In this rigorous quantum framework, we stop treating the MOSFET as a simple resistor or switch. Instead, the source and drain contacts act as infinite electron suppliers, and the device channel is treated as an interacting quantum region. NEGF allows us to calculate the exact probability of transmission by treating the electrons purely as quantum waves, flawlessly accounting for both the ballistic transport and the source-drain tunneling that occurs in these ultra-scaled devices where drift-diffusion fails

Sources:

1. Semiconductor physics and devices, by Donald A. Neamen
2. Transport in Nanostructures, by David K Ferry; Stephen Marshall Goodnick; Jonathan P Bird