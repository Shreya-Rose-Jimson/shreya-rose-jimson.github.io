# Second Order Effects in MOSFETS: Ballistic Transport

### Second Order Effects in MOSFETS: Ballistic transport

![](https://cdn-images-1.medium.com/max/1200/1*RfA4BZuVjG3obfKzjYzgKA.gif)

Imagine you are trying to sprint down a densely packed school hallway. No matter how hard you push yourself forward, you constantly bump into other students, lose all your momentum, and have to start accelerating from zero all over again. In a standard macroscopic semiconductor, our electrons face the exact same frustrating journey; they are constantly colliding with vibrating lattice atoms (phonons) and impurities, leading to a steady, average “drift velocity” governed by the material’s mobility.

But what if we shrink the length of that hallway until it is shorter than the average distance between the students? Suddenly, you can sprint from one end to the other without a single collision!

This is the beautiful, frictionless reality of **Ballistic Transport**.

![](https://cdn-images-1.medium.com/max/1200/1*q0e99GEgR-qijTLz7rXYeA.gif)

**1. The Breakdown of the Classical Rules**

In our classical transport models, we rely heavily on the concept of mobility (*μ*) and the drift velocity equation, *v_d*=*μ*E. However, this entire mathematical formalism secretly hinges on the assumption that the channel length (*L*) is vastly larger than the mean distance between scattering events (*l*).

As modern fabrication technology aggressively shrinks the MOSFET channel length down to the submicron and nanometer regime, *L* becomes comparable to, or even less than, *l*. When *L*<*l*, a massive fraction of the charge carriers travel from the source to the drain without experiencing a single scattering event. The electrons essentially behave like perfect ballistic projectiles, identical to electrons flying through the vacuum of an old-fashioned vacuum tube. Because they suffer no collisions, the concept of mobility becomes mathematically meaningless.

**2. The Return to Newtonian Elegance**

If the electrons are no longer held back by the “friction” of scattering, how do we model their motion? We abandon the drift-diffusion equations and return to the absolute purity of Newton’s second law.

For an electron of effective mass *m*∗ in an electric field E, the equation of motion is strictly deterministic:

![](https://cdn-images-1.medium.com/max/1200/1*Jtka6p9leZjGNGK0adfROg.png)

Because the electron is accelerating continuously without losing energy to the lattice, it achieves staggering velocities. We can rigorously calculate the transit time (*τtr*) it takes for an electron to cross this ballistic device. Using standard kinematics where distance *L*=21*at*2 and acceleration *a*=*e*E/*m*∗, the transit time collapses to:

![](https://cdn-images-1.medium.com/max/1200/1*OMF2UBpiLd6BK0ocPsuR8Q.png)

In incredibly short devices, this ballistic transit time is fundamentally shorter than the time predicted by saturation velocity limits, tying perfectly into our previous conversations on velocity overshoot.

**3. The Quantum Mechanical Reality (The Landauer Formula)**

When transport is completely ballistic, the carriers traverse the active region without scattering, meaning their quantum mechanical wavefunctions retain perfect phase coherence from the source to the drain. Because of this, we must shift our perspective from treating electrons as classical particles to treating them as interacting matter waves.

![](https://cdn-images-1.medium.com/max/1200/1*MvQdphPMcrazyxi9u05yEw.gif)

Furthermore, if the electrons never collide with the lattice in the channel, they never dissipate heat (Joule heating) in the active device region. All the excess kinetic energy they acquire from the electric field is carried entirely across the channel and violently dumped into the drain contact, where the actual energy dissipation finally occurs.

To calculate the current in this coherent, ballistic regime, we use the magnificent **Landauer formula**. Since the electrons move elastically as waves, the conductance (*G*) of a 1D ballistic channel is governed entirely by the quantum transmission probability (*T*) of the electron wave passing through the structure. The conductance is elegantly defined as:

![](https://cdn-images-1.medium.com/max/1200/1*Ra7SvPGy_a0BjO8XgcuQ0A.png)

If the ballistic channel is perfectly open and transparent, the transmission probability *T*=1. The conductance of a single, perfect ballistic channel is therefore universally quantized to exactly *h*2*e*2 (approximately 7.748×10−5 Siemens), determined solely by the charge of an electron and Planck’s constant.

**4. The Relocation of Heat (Dissipation)**

In a classical macroscopic device, electrons constantly collide with the lattice, meaning energy is dissipated as heat throughout the active channel region.

In a ballistic device, however, this spatial distribution of heat completely shifts. Because the electrons traverse the active region without scattering, energy is no longer dissipated inside the channel itself. Instead, an electron leaving the source arrives at the drain with a massive excess kinetic energy (*eV*), and this energy is violently dissipated only when the electron crashes into the metal contacts (reservoirs).

**5. The Catastrophic Loss of Saturation (The Langmuir-Child Law)**

Here is the magnificent, yet terrifying twist for circuit designers! You might think ballistic transport is the ultimate goal, but for a standard MOSFET, it is actually highly detrimental.

![](https://cdn-images-1.medium.com/max/1200/1*wxCD2ZdMeY9Q5xOZw6FQpA.gif)

In a normal transistor, the scattering events in the channel actually perform a crucial “screening” function — they isolate the source’s space-charge region from variations in the drain potential. When we lose this scattering in the ballistic regime, the device characteristics physically regress to the physics of vacuum diodes, governed by the Langmuir-Child law where current follows the relationship *I*∝*L*2*V*3/2.

The beautiful, flat saturation region that we desperately need for high-gain amplifiers and digital logic completely vanishes! The transistor transitions into “triode-like” characteristic curves with a severely degraded, low output drain resistance. In fact, because the drain potential reaches straight through the frictionless channel to modulate the source, this extreme ballistic behavior manifests exactly like catastrophic Drain-Induced Barrier Lowering (DIBL).

![](https://cdn-images-1.medium.com/max/1200/1*7F5Ef4duVxRjRPxf30NCAQ.gif)

By removing all the microscopic friction to achieve ultimate speed, we mathematically destroy the very transistor action that makes the device useful!

Sources:

1. Transport in Nanostructures, by David K Ferry; Stephen Marshall Goodnick; Jonathan P Bird
2. Semiconductor Device Physics and Design, by Umesh K Mishra, Jasprit Singh