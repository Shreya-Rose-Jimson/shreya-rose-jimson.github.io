# Semiconductor Device Physics

[Second Order Effects in MOSFETS: Channel Length Modulation](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Channel%20Length%20Mod%2038ae1e959a55801e8f97f88b9b32e642.md)

[Second Order Effects in MOSFETS: Body Effect ](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Body%20Effect%2038ae1e959a55802b9453d2475107e63b.md)

[Second Order Effects in MOSFETS: Short-Channel Effects (SCE)](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Short-Channel%20Effe%2038ae1e959a5580739d4ce55177517fd0.md)

[Second Order Effects in MOSFETS: Narrow Width Effect](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Narrow%20Width%20Effec%2038ae1e959a55801986b6fea9d44b6f52.md)

[Second Order Effects in MOSFETS: Mobility Degradation](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Mobility%20Degradati%2038ae1e959a558021be6fc7c87a6a8b1c.md)

[Second Order Effects in MOSFETS: Surface Roughness Scattering](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Surface%20Roughness%20%2038ae1e959a5580729296fbe030fe1720.md)

[Second Order Effects in MOSFETS: **Coulomb Scattering** ](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Coulomb%20Scattering%2038ae1e959a558051a1c5c015eaa4c03e.md)

[Second Order Effects in MOSFETS: Velocity Saturation](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Velocity%20Saturatio%2038ae1e959a5580ef803cfa720cabcc84.md)

[Second Order Effect in MOSFETS: Velocity Overshoot](Semiconductor%20Device%20Physics/Second%20Order%20Effect%20in%20MOSFETS%20Velocity%20Overshoot%2038ae1e959a55806fa7ebf22b56aeab85.md)

[Second Order Effects in MOSFETS: Ballistic Transport](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Ballistic%20Transpor%2038ae1e959a5580c08907d53ace0cf770.md)

[Second Order Effect in MOSFETS: Quasi Ballistic Transport](Semiconductor%20Device%20Physics/Second%20Order%20Effect%20in%20MOSFETS%20Quasi%20Ballistic%20Tra%2038ae1e959a5580bab233fcc9b0dec507.md)

[Second Order Effects in MOSFETS: Subthreshold Conduction](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Subthreshold%20Condu%2038ae1e959a5580559de1e675d145d0a8.md)

[Second Order Effects in MOSFETS: Junction Leakage](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Junction%20Leakage%2038ae1e959a55801c919acf934f1fd149.md)

[Second Order Effects in MOSFETS: Gate-Induced Drain Leakage (GIDL)](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Gate-Induced%20Drain%2038ae1e959a55808aaacae23f29f550eb.md)

[Second Order Effects in MOSFETS: Band-to-band tunneling (BTBT)](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Band-to-band%20tunne%2038ae1e959a5580d8b273e77c2b992b9e.md)

[Second Order Effects in MOSFETS: Gate oxide tunneling](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Gate%20oxide%20tunneli%2038ae1e959a55802da590ea4f26211fa5.md)

[**Second Order Effects in MOSFETS: Source-Drain Tunneling**](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Source-Drain%20Tunne%2038ae1e959a5580d29da2da1a3829048b.md)

[Second Order Effects in MOSFETS: Impact Ionization](Semiconductor%20Device%20Physics/Second%20Order%20Effects%20in%20MOSFETS%20Impact%20Ionization%2038ae1e959a5580228ea6deadb230236c.md)